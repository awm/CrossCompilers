#ifndef _TRACE_SCHED_H
#define _TRACE_SCHED_H

#include <linux/sched.h>
#include <linux/tracepoint.h>

#include <trace/sched_event_types.h>

#endif
