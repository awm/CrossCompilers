/* trace/<type>.h here */

#include <trace/sched.h>
#include <trace/irq.h>
#include <trace/lockdep.h>
