#ifndef _TRACE_IRQ_H
#define _TRACE_IRQ_H

#include <linux/interrupt.h>
#include <linux/tracepoint.h>

#include <trace/irq_event_types.h>

#endif
