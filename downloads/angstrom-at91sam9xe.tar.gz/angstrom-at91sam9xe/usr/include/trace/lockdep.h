#ifndef _TRACE_LOCKDEP_H
#define _TRACE_LOCKDEP_H

#include <linux/lockdep.h>
#include <linux/tracepoint.h>

#include <trace/lockdep_event_types.h>

#endif
