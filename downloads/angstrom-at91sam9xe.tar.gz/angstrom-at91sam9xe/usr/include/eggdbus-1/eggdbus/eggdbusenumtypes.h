
/* Generated data (by glib-mkenums) */

#ifndef __EGG_DBUS_ENUM_TYPES_H__
#define __EGG_DBUS_ENUM_TYPES_H__

#include <glib-object.h>

G_BEGIN_DECLS

/* enumerations from "eggdbusinterface.h" */
GType egg_dbus_interface_property_info_flags_get_type (void) G_GNUC_CONST;
#define EGG_TYPE_DBUS_INTERFACE_PROPERTY_INFO_FLAGS (egg_dbus_interface_property_info_flags_get_type ())

/* enumerations from "eggdbusconnection.h" */
GType egg_dbus_call_flags_get_type (void) G_GNUC_CONST;
#define EGG_TYPE_DBUS_CALL_FLAGS (egg_dbus_call_flags_get_type ())
GType egg_dbus_bus_type_get_type (void) G_GNUC_CONST;
#define EGG_TYPE_DBUS_BUS_TYPE (egg_dbus_bus_type_get_type ())

/* enumerations from "eggdbuserror.h" */
GType egg_dbus_error_get_type (void) G_GNUC_CONST;
#define EGG_TYPE_DBUS_ERROR (egg_dbus_error_get_type ())

/* enumerations from "eggdbusmessage.h" */
GType egg_dbus_message_type_get_type (void) G_GNUC_CONST;
#define EGG_TYPE_DBUS_MESSAGE_TYPE (egg_dbus_message_type_get_type ())
G_END_DECLS

#endif /* __EGG_DBUS_ENUM_TYPES_H__ */

/* Generated data ends here */

